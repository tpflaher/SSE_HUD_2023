# SoftwareSerialTX
A SoftwareSerial implementation only for transmitting data, maximum size reduced 

An ATMega implementation of a SoftwareSerial class only used for sending data.
Main focus is a minimum usage of code/ram.
